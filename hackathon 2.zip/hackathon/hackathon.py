from io import StringIO

from fastapi import FastAPI, Depends, HTTPException, status, UploadFile, File
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from jose import JWTError, jwt
from fastapi.responses import FileResponse
import jose
from pydantic import BaseModel
import aiofiles
from typing import Optional
import pandas as pd
import uvicorn
from datetime import datetime, timedelta
from sklearn.cluster import KMeans
import os
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins. Change to specific domains in production.
    allow_credentials=True,
    allow_methods=['GET','POST'],  # Allow all HTTP methods (GET, POST, etc.)
    allow_headers=["*"],  # Allow all headers
)

ALLOWED_HOSTS = ['*']

CORS_ALLOWED_ORIGINS = [
    'http://localhost:3000',
    'http://127.0.0.1:3000',
]
CORS_ALLOW_CREDENTIALS = True

# Secret key to encode and decode the JWT
SECRET_KEY = "your_secret_key"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# In-memory fake users database
fake_users_db = {
    "test_user": {
        "username": "test_user",
        "password": "test_password",
    }
}

# Pydantic model for the token response
class Token(BaseModel):
    access_token: str
    token_type: str

# Dependency for OAuth2 password flow
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")

# Function to create a JWT token
def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jose.jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

# Function to authenticate the user
def authenticate_user(username: str, password: str):
    user = fake_users_db.get(username)
    if not user or user["password"] != password:
        return False
    return user

# Function to verify the token and extract the username
def get_current_user(token: str = Depends(oauth2_scheme)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jose.jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
    except jose.JWTError:
        raise credentials_exception
    user = fake_users_db.get(username)
    if user is None:
        raise credentials_exception
    return user

@app.get("/")
async def root():
    return {"message": "<html><body>Hello Team-Freshworks..!! Welcome you all to the Hackathon</body></html>"}

# Login endpoint to authenticate user and return JWT token
@app.post("/login", response_model=Token)
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    user = authenticate_user(form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user["username"]}, expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}

"""
@app.get("/{app_name}")
async def say_hello(app_name: str):
    return {"message": f"Hello {app_name}"}
"""
@app.post("/file")
async def create_upload_file(file: UploadFile = File(...),current_user: str = Depends(get_current_user)):
    csv = await file.read()
    if file.content_type not in ['text/csv']:
        raise HTTPException(status_code=406, detail="Please upload only .csv files")
    async with aiofiles.open(f"{file.filename}", "wb") as f:
        await f.write(csv)
    s = str(csv, 'utf-8')
    data = StringIO(s)
    df = pd.read_csv(data)
    data.close()
    print(type(file))
    print(df)
    return {"filename": file.filename}

@app.get("/download-result")
async def download_result(filename:str,algorithm:str,current_user: str = Depends(get_current_user)):
    file_location = filename+ "_" + algorithm + ".csv"
    if os.path.isfile(file_location):
        return FileResponse(file_location, media_type='text/csv', filename=file_location)
    else:
        raise HTTPException(status_code=406, detail="Please provide a valid filename")

#sklearn_model = KMeans(n_clusters=5)
#sklearn_centroids = sklearn_model.fit(csv)
