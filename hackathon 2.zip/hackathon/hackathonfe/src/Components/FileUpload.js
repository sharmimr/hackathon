import React, { useState } from 'react';
import axios from 'axios';
import { Container, Form, Button } from 'react-bootstrap';

function FileUpload() {
  const [selectedFile, setSelectedFile] = useState(null);
  const [error, setError] = useState('');

  const handleFileChange = (event) => {
    setError('');
    const file = event.target.files[0];  // Select the file
    setSelectedFile(file);  // Store the selected file in state
  };

  const handleFileUpload = async () => {
    if (!selectedFile) {
      console.error('No file selected');
      setError('No file selected')
      return;
    }

    const formData = new FormData();
    formData.append('file', selectedFile);  // Append the file to FormData

    const accessToken = localStorage.getItem('access_token');  // Fetch token

    try {
      const response = await axios.post('http://localhost:8000/file', formData, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,  // Add token
        },
      });
      console.log('File uploaded successfully:', response.data.filename);
      alert('File uploaded successfully:', response.data.filename)
    } catch (error) {
        console.log(error.response.data.detail)
      console.error('File upload error:', error.response?.data.detail || error.message);
      setError('File upload error:', error.response?.data?.detail)
    }
  };

  return (
    <>
        <Container className="mt-5">
          <div className="title">File Upload</div>
          <Form style={{margin: '30px'}}>
            {/* Multiple File Upload Input */}
            <Form.Group controlId="fileUpload">
              <Form.Label>Choose files to upload</Form.Label>
              <Form.Control type="file" multiple onChange={handleFileChange} />
            </Form.Group>
          </Form>
          <Button variant="primary" onClick={handleFileUpload}>
            Upload File
          </Button>
{error && <span style={{color: 'red'}}> {error} </span>}
    </Container>
    </>
  );
}

export default FileUpload;
