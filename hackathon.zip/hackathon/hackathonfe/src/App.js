import Login from './Components/Login';
import FileUpload from './Components/FileUpload';
import './App.css';
import {BrowserRouter as Router, Routes, Route} from "react-router-dom";

function App() {
  return (
    <div className="App">
      {/* <Login/> */}
      <Routes>
        {/* <Route path="/" element={<Login />} exact/> */}
        <Route path="/login" element={<Login />} />
        <Route path="/fileUpload" element={<FileUpload />} />
      </Routes>
    </div>
  );
}

export default App;